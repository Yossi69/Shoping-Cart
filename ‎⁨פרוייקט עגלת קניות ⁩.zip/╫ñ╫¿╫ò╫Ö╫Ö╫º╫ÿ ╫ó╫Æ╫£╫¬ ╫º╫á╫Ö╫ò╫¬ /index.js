let products = [
  ["item1", 100],
  ["item2", 150],
  ["item3", 155],
];
let cart = [];

let totalPrice = 0;

document.addEventListener("click", OnClick);

function OnClick(e) {
  if (e.target.className == "addButton") {
    let itemInfoH1 = document.createElement("h1");
    let item1info =
      e.target.parentElement.getElementsByClassName("info")[0].innerText;
    itemInfoH1.innerText = item1info;
    let shoppingCartDiv = document.getElementsByClassName("shopingCart");
    shoppingCartDiv[0]
      .getElementsByClassName("CartProducts")[0]
      .appendChild(itemInfoH1);

    let price = e.target.parentElement
      .getElementsByClassName("info")[0]
      .getElementsByClassName("shoePrice")[0].innerText;
    totalPrice = parseInt(totalPrice) + parseInt(price) + "$";

    document
      .getElementsByClassName("shopingCart")[0]
      .getElementsByClassName("totalPrice")[0].innerText =
      "Total Price :" + totalPrice.toString();
  }

  if (e.target.className == "clearButton") {
    removeAllChildNodes(e.target.parentElement);
  }
}

function removeAllChildNodes(parent) {
  let products = parent.getElementsByClassName("CartProducts")[0];
  while (products.firstChild) {
    products.removeChild(products.firstChild);
  }

  totalPrice = "0$";

  document
    .getElementsByClassName("shopingCart")[0]
    .getElementsByClassName("totalPrice")[0].innerText =
    "Total Price :" + totalPrice.toString();
}
